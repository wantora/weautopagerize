weAutoPagerize
Copyright (c) 2017 wantora

This software is licensed under The GNU General Public License 3.0 or later.
https://www.gnu.org/licenses/gpl.html

--------

AutoPagerize
http://autopagerize.net/

this script based on
GoogleAutoPager(http://la.ma.la/blog/diary_200506231749.htm) and
estseek autopager(http://la.ma.la/blog/diary_200601100209.htm).
thanks to ma.la.

Released under the GPL license
http://www.gnu.org/copyleft/gpl.html

--------

uAutoPagerize
http://d.hatena.ne.jp/Griever/

this script based on
AutoPagerize(http://autopagerize.net/).

Released under the GPL license
http://www.gnu.org/copyleft/gpl.html
